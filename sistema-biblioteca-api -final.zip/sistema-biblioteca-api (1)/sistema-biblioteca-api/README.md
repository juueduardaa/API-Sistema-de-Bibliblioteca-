# Sistema de Biblioteca — API REST (Spring Boot)

API RESTful para gerenciar uma biblioteca: leitores, carteirinhas, livros, autores, categorias e empréstimos.
Usa Spring Boot 4.1.1, Java 17+, Spring Data JPA, H2, Bean Validation, Spring HATEOAS e Springdoc OpenAPI (Swagger).

> **Status de validação (leia antes de entregar):** este projeto foi revisado linha a linha e conferido
> sintaticamente, mas **o build não pôde ser executado no ambiente onde foi gerado** (sem acesso ao Maven Central).
> Os testes de integração em `src/test` foram escritos justamente para você confirmar, com um clique, que
> tudo compila e que o Swagger sobe. Veja a seção "Como confirmar que está funcionando".

---

## 1. Pré-requisitos

| Item | Versão | Observação |
|---|---|---|
| JDK | 17 ou superior (21 recomendado) | No IntelliJ: *File → Project Structure → SDK → Download JDK* |
| IntelliJ IDEA | Community ou Ultimate | O Maven já vem embutido no IntelliJ |
| Internet | — | Necessária na 1ª abertura para baixar as dependências |

Não é preciso instalar Maven nem banco de dados: o H2 roda em memória dentro da aplicação.

## 2. Passo a passo no IntelliJ IDEA

1. **Extraia** o ZIP. Você terá a pasta `sistema-biblioteca-api` (a que contém o `pom.xml`).
2. No IntelliJ: **File → Open…** e selecione a pasta `sistema-biblioteca-api` (a do `pom.xml`). Se perguntar, escolha **Trust Project**.
3. Aguarde o IntelliJ importar o projeto: no canto inferior direito aparece a barra "Resolving dependencies / Indexing".
   Se aparecer um balão **"Maven projects need to be imported"**, clique em **Load Maven Changes**
   (ou abra a aba **Maven** à direita e clique no ícone de recarregar 🔄).
4. Confira o JDK: **File → Project Structure → Project → SDK** deve estar em 17 ou superior.
5. Abra `src/main/java/com/senac/tsi/MinhaPrimeiraApi/MinhaPrimeiraApiApplication.java`
   e clique no triângulo verde ▶ ao lado de `main` → **Run 'MinhaPrimeiraApiApplication'**.
6. No console deve aparecer algo como `Started MinhaPrimeiraApiApplication in X seconds`
   e `Tomcat started on port 8080`.
7. Abra o navegador em **http://localhost:8080/swagger-ui.html** (a raiz `http://localhost:8080/` redireciona para lá).

Para parar a aplicação: botão quadrado vermelho ■ na janela *Run*.

### Alternativa pelo terminal
```bash
./mvnw spring-boot:run        # Linux/macOS
mvnw.cmd spring-boot:run      # Windows
```
(o `mvnw` baixa o Maven sozinho; precisa de internet)

## 3. Como confirmar que está funcionando

**Opção A — rodar os testes (recomendado):** no IntelliJ, clique com o botão direito na pasta `src/test/java`
→ **Run 'All Tests'**. Dois testes sobem a aplicação de verdade e verificam:
- `/v3/api-docs` lista as 6 rotas e `/swagger-ui/index.html` responde 200;
- o fluxo completo: criar categoria → autor → leitor → livro → carteirinha → empréstimo, regras de negócio (409), validação (400), 404, buscas paginadas, devolução e exclusões.

Verde = compila, sobe, Swagger e API funcionando. (No terminal: `./mvnw test`.)

**Opção B — manualmente:** abra o Swagger UI e siga a seção 5.

## 4. Endereços úteis

| O que | URL |
|---|---|
| Swagger UI | http://localhost:8080/swagger-ui.html |
| OpenAPI (JSON) | http://localhost:8080/v3/api-docs |
| Índice HATEOAS da API | http://localhost:8080/api |
| Console do H2 | http://localhost:8080/h2-console (JDBC URL `jdbc:h2:mem:biblioteca`, usuário `sa`, senha vazia) |

O banco é **em memória**: os dados somem ao reiniciar. Ao iniciar, a aplicação carrega dados de exemplo
(2 categorias, 2 autores, 2 livros, 2 leitores, 1 carteirinha, 1 empréstimo). Para começar vazio,
use `app.seed.enabled=false` em `application.properties`.

## 5. Testando no Swagger UI

1. Abra `GET /api/livros` → **Try it out** → **Execute**. Já vem com os dados de exemplo.
2. Para criar dados na ordem certa (um depende do outro): **Categoria → Autor → Leitor → Livro → Carteirinha → Empréstimo**.
   Cada `POST` já vem com um corpo de exemplo preenchido; troque os IDs pelos que a API devolveu.
3. Observe o campo `_links` em cada resposta (HATEOAS): `self`, `update`, `delete`, links para recursos relacionados.
4. Tente provocar erros: e-mail repetido (409), campo vazio (400), ID inexistente (404).

## 6. Recursos e endpoints (6 por entidade)

| Recurso | Base | Operações | Busca personalizada (paginada) |
|---|---|---|---|
| Leitores | `/api/leitores` | GET (lista), POST, GET `/{id}`, PUT `/{id}`, DELETE `/{id}` | `GET /buscar?nome=ana` |
| Carteirinhas | `/api/carteirinhas` | idem | `GET /buscar?codigo=CAR` |
| Livros | `/api/livros` | idem | `GET /buscar?titulo=hobbit` |
| Autores | `/api/autores` | idem | `GET /buscar?nome=tolkien` |
| Categorias | `/api/categorias` | idem | `GET /buscar?nome=fantasia` |
| Empréstimos | `/api/emprestimos` | idem + `POST /{id}/devolucao` | `GET /buscar?status=ATIVO` |

Todas as listagens aceitam `?page=0&size=10&sort=campo,asc`.

Códigos HTTP: `200` OK · `201` Created (com cabeçalho `Location`) · `204` No Content (exclusão) ·
`400` dados inválidos · `404` não encontrado · `409` conflito (duplicidade ou regra de negócio).

## 7. Mapa dos requisitos

| Requisito | Onde está |
|---|---|
| Spring Boot recente, Java 17+, Maven, H2, JPA | `pom.xml`, `application.properties` |
| 6 entidades | `model/` (Leitor, Carteirinha, Livro, Autor, Categoria, Emprestimo) |
| One-to-One | Leitor ↔ Carteirinha |
| One-to-Many | Categoria → Livro; Leitor → Empréstimo; Livro → Empréstimo |
| Many-to-Many | Livro ↔ Autor (tabela `livro_autor`) |
| Enum | `StatusEmprestimo` (ATIVO, DEVOLVIDO, ATRASADO) |
| Bean Validation | anotações nas entidades (`model/`) e nos DTOs de entrada (`dto/*Request`) |
| CRUD + paginação + consulta personalizada | `controller/` + `service/` + `repository/` |
| Swagger completo | `@Tag`, `@Operation`, `@ApiResponses`, `@Schema(example=…)` nos controllers e DTOs; `config/OpenApiConfig` |
| HATEOAS | `assembler/` (EntityModel), `PagedModel` nas listagens, índice em `/api` |
| Tratamento de erros | `exception/ApiExceptionHandler` (formato JSON único `ApiError`) |

Regras de negócio extras (em `EmprestimoService`): só empresta quem tem carteirinha **ativa**; livro emprestado fica
indisponível; devolver libera o livro; não exclui categoria/autor/leitor/livro que ainda estejam em uso.

## 8. Estrutura de pastas

```
src/main/java/com/senac/tsi/MinhaPrimeiraApi/
├── MinhaPrimeiraApiApplication.java
├── config/       OpenApiConfig, DataLoader (dados de exemplo)
├── model/        entidades JPA + enum
├── repository/   Spring Data JPA (consultas paginadas)
├── dto/          *Request (entrada + validação) e *Response (saída)
├── service/      regras de negócio e transações
├── assembler/    montagem dos recursos HATEOAS
├── controller/   endpoints REST + anotações do Swagger
└── exception/    erros padronizados
```

Por que DTOs? Expor as entidades JPA direto no JSON causa erros de carregamento preguiçoso (lazy) e loops
entre relacionamentos. Os DTOs evitam isso e deixam a documentação do Swagger limpa.

## 9. Problemas comuns

| Sintoma | Causa provável / solução |
|---|---|
| `release version 17 not supported` / `invalid source release` | O IntelliJ está usando um JDK menor que 17. *File → Project Structure → SDK* e também *Settings → Build → Compiler → Java Compiler*. |
| Dependências em vermelho / `Cannot resolve` | Sem internet ou Maven não recarregado: aba **Maven → 🔄 Reload**. |
| `Port 8080 was already in use` | Outra aplicação usa a porta. Pare-a ou adicione `server.port=8081` em `application.properties`. |
| Swagger abre mas aparece "Failed to load API definition" | Abra `/v3/api-docs` no navegador: a mensagem de erro mostrada ali indica o problema. Envie-a para análise. |
| Erro no console ao iniciar | Copie a mensagem **completa**, em especial a linha `Caused by:` mais ao final. |
